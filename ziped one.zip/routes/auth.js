const router=require('express').Router();
const User=require('../models/User');

router.post("/register",async (req,res)=>{
    console.log(req.body);
    const newUser=new User({
        username:req.body.username,
        email:req.body.email,
        password:req.body.password
    });
    try{
        const saveUser=await newUser.save();
    // console.log(saveUser);
    res.status(200).json(saveUser);
    }catch(err){
        // console.log(err);
        res.status(500).json(err);
    }
    
})

router.post("/login",async (req,res)=>{
    let user= await User.findOne({username:req.body.username});

    if(user){
        if(user.password==req.body.password){
            res.status(200).json("Login Successfull");
        }else{
            res.status(401).json("Invalid Crediential");
        }
    }else{
        res.status(401).json("Invalid Crediential");
    }
})

module.exports=router;  