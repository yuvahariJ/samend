const express=require('express');
const app=express();
const userRoute=require("./routes/user")
const dotenv=require("dotenv");
dotenv.config(); 
const mongoose=require('mongoose');
mongoose.set('strictQuery', false);
const authRoute=require('./routes/auth');

const bodyparser=require('body-parser')
app.use(bodyparser.urlencoded({extended:true}));


mongoose.connect(process.env.MONGODB_URL)
.then(()=>{console.log("Connecto to Db ");})
.catch((err)=>{
    console.log("Error Occured");
});
app.use(express.json());
app.use("/api/user",userRoute);
app.use("/api/auth",authRoute);
app.listen(process.env.PORT||3100,()=>{
    console.log("Backend server running on 3100");
})