const router=require('express').Router();
const Pizza=require("../models/Pizza");

router.get("/addpizza",async (req,res)=>{
    const newPizza=new Pizza({
        id:req.query.id,
        type:req.query.type,
        price:req.query.price,
        name:req.query.name
    })

    try{
        const savePizza=await newPizza.save();
        res.status(200).json(savePizza);
    }catch(err){
        res.status(400).json(err);
    }


})

router.get("/getallpizza",async (req,res)=>{
    let pizzalist=await Pizza.find();
    res.send(JSON.stringify(pizzalist));
})

module.exports=router; 