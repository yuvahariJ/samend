const router=require('express').Router();


router.get("/cart",(req,res)=>{
    
})

module.exports=router; 