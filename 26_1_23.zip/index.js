const express=require('express');
const app=express();
const userRoute=require("./routes/user")
const dotenv=require("dotenv");
const mongoose=require('mongoose');
const authRoute=require('./routes/auth');
const bodyparser=require('body-parser')
const pizzaRoute=require('./routes/pizza');



app.use(bodyparser.urlencoded({extended:true}));
dotenv.config(); 
mongoose.set('strictQuery', false);
mongoose.connect(process.env.MONGODB_URL)
.then(()=>{console.log("Connecto to Db ");})
.catch((err)=>{
    console.log("Error Occured");
});


app.use(express.json());
app.use("/api/user",userRoute);
app.use("/api/auth",authRoute);
app.use("/api/pizza",pizzaRoute);



app.listen(process.env.PORT||3100,()=>{
    console.log("Backend server running on 3100");
})